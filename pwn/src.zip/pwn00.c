#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

struct user
	{
		char pwd[128];
		char usn[128];
		unsigned int canary;
	};
unsigned int tmp=0;
unsigned int s=0;
unsigned int islogin=0;
char username[256];
char password[256];

void init(){
	alarm(180);
	srand(time(NULL));
	unsigned char *p=&tmp;
	int c=0;
	do{
		char ch=rand()%0x7f;
		if(ch > 0x20 && ch < 0x7f){
			*(p+c)=ch;
			++c;
			s=ch;
		} 
	}while(c < 4);
	setbuf(stdout,NULL);
	setbuf(stderr,NULL);
}
void flag(){
	char flag[100]={0};
	FILE *f;
	f=fopen("flag.txt","r");
	if(f ==NULL){
		perror("open");
		exit(1);
	}
	fread(flag,sizeof(flag),1,f);
	fclose(f);
	puts(flag);
	exit(1);
}
void xxxx(){
	char sh[0x1000]={0};
	FILE *f;
	f=fopen("xxxx.txt","r");
	if(f ==NULL){
		perror("open");
		exit(1);
	}
	fread(sh,sizeof(sh),1,f);
	fclose(f);
	puts(sh);
}
void salt_e(char *text, int shift, int num)
{
    for (int i=0; i < num; i++)
    {	
        if (text[i] >= 'A' && text[i] <= 'Z')
        {
            text[i] = (char)(((text[i] + shift - 'A' + 26) % 26) + 'A');
        }
        else if (text[i] >= 'a' && text[i] <= 'z')
        {
            text[i] = (char)(((text[i] + shift - 'a' + 26) % 26) + 'a');
        }
    }
}
int len(char *buf){
	int c=0;
	char ch=buf[c];
	while(ch!=10 && ch!=0){
		ch=buf[c++];
	}
	return c;

}
void signin(){
	struct user ME;
	ME.canary=tmp;
	if(!islogin){
	memset(ME.pwd,0,256);
	printf("username :");
	read(0,ME.usn,255);
	printf("password :");
	read(0,ME.pwd,255);
	salt_e(ME.usn,s,len(ME.usn));
	salt_e(ME.pwd,s,len(ME.pwd)); 
	if(!strncmp(ME.usn,username,len(username)-1)){
		if(!strncmp(ME.pwd,password,len(password)-1)){
			printf("Hello %s",ME.usn);
			printf("Flag is secret....\n");
			islogin=1;
		}
		else{
			printf("pls check username/password...\n");
		}
	}
	else{
		printf("pls check username/password...\n");
	}
	}
	else{
		printf("Flag is secret....\n");
	}
	if(ME.canary!=tmp){
		printf("DETECT BOF .......\n");
		exit(1);
	}
}
void signup(){
	memset(username,0,256);
	memset(password,0,256);
	char re[256]={0};
	printf("username    :");
	read(0,username,255);
	printf("password    :");
	read(0,password,255);
	printf("re-password :");
	read(0,re,255);
	if(len(username) > 8 && len(password) > 8 && !strcmp(password,re)){
		printf("success...\n");
		salt_e(username,s,len(username));
		salt_e(password,s,len(password));
		islogin=0;
		return;
	}
	printf("try again....\n");
	memset(username,0,256);
	memset(password,0,256);
	return;
}
void menu(){

	puts("=========MENU=============");
	puts("1. Sign-in");
	puts("2. Sign-up/Sign-out");
	puts("3. Hint and quit");
	char a[8];
	int choice=0;
	while(1){
		printf("Choice : ");
		read(0,a,8);
		a[strcspn(a,"\n")]=0;
		choice = atoi(a);
		if(choice==1){
			signin();
		}
		else if(choice==2){
			signup();
		}
		else{
			printf("Hint : none\n");
			printf("goodbye..\n");
			break;
		}
	}
}
int main(){
	init();
	xxxx();
	menu();
	return 0;
}